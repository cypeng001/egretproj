class VectorUtil {
	public static calcLength(x: number, y: number): number {
		return Math.sqrt(x * x + y * y);
	}

	public static calcNormalize(x: number, y: number): [number, number] {
		var len = VectorUtil.calcLength(x, y);
		return [x / len, y / len];
	}

	public static calcDir(x1: number, y1: number, x2: number, y2: number): [number, number] {
		var x_len = x2 - x1;
		var y_len = y2 - y1;

		var len = VectorUtil.calcLength(x_len, y_len);
		if(len == 0) {
			return [0, 0];
		}

		return [x_len / len, y_len / len];
	}

	public static calcTarPos(x: number, y: number, dir_x: number, dir_y: number, len: number): any {
		return [x + dir_x * len, y + dir_y * len];
	}

	public static radian2Degree(radian) {
		return radian / Math.PI * 180;
	}

	public static degree2Radian(degree) {
		return degree / 180 * Math.PI;
	}

	public static calcRadian(x: number, y: number): number {
		var radian = Math.atan(Math.abs(y / x));
		if(x > 0) {
			if(y > 0) {
				return radian;
			}
			else {
				return 2 * Math.PI - radian;
			}
		}
		else {
			if(y > 0) {
				return Math.PI - radian;
			}
			else {
				return Math.PI + radian;
			}
		}
	}

	public static calcDegree(x: number, y: number): number {
		return VectorUtil.radian2Degree(VectorUtil.calcRadian(x, y));
	}
}