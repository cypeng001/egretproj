class BattleObject extends egret.DisplayObjectContainer {
	//protected static SHADOW_WIDTH: number = 57;
	//protected static SHADOW_HEIGHT: number = 37;
	public static DEF_ENTER_STAGE_DIST: number = 200;
	public static DEF_SPEED: number = 66;

	protected static ATK_ACT_STS: any = {
		[BattleObjGroup.BOG_A]: [BattleObjActSt.BOAS_ATKUP_A, 
								BattleObjActSt.BOAS_ATTACK_A, 
								BattleObjActSt.BOAS_ATKDOWN_A],
		[BattleObjGroup.BOG_B]: [BattleObjActSt.BOAS_ATKUP_B, 
								BattleObjActSt.BOAS_ATTACK_B, 
								BattleObjActSt.BOAS_ATKDOWN_B],
	};

	protected _battleLayer: BattleLayer;

	protected _id: number = 0;
	protected _heroId: number = 0;
	protected _resType: number = 0;
	protected _resId: number = 0;
	protected _actionState: number = 0;
	protected _group: number = 0;
	protected _standPos: number = 0;
	protected _name: string;
	protected _oriPos: [number, number] = null;
	protected _moveDir: [number, number] = null;
	protected _speed: number = BattleObject.DEF_SPEED;

	protected _hp: number = 0;
	protected _hpLim: number = 0;
	
	protected _battleObjCnf: any = null;

	protected _hpBar: eui.ProgressBar;
	protected _nameLabel: eui.Label;
	protected _shadow: eui.Image = null;
	protected _sprite: MovieClip = null;

	protected _effectDatas: any = [];
	protected _spActs: any = [];

	protected _isDead: boolean = false;
	protected _footprintTick: number = 0;
	
	public constructor() {
		super();

		this.touchEnabled = false;
		this.touchChildren = false;
	}

	public init(battleLayer: BattleLayer, data: any) {
		this._battleLayer = battleLayer;

		this._id = data.handle;
		this._heroId = data.heroid;
		this._group = data.posFlag;
		this._standPos = data.position;

		this._hp = data.hp;
		this._hpLim = data.hpLim;
		this._name = data.name;

		this._battleObjCnf = BattleObjCnf[this._heroId];
		this._resType = this._battleObjCnf.resType;
		this._resId = this._battleObjCnf.resId;

		this._oriPos = BattleUtil.getPos(this._group, this._standPos);
		this._moveDir = BattleUtil.getMoveDir(this._group);
		
		var initPos = BattleUtil.getInitPos(this._group, this._standPos, BattleObject.DEF_ENTER_STAGE_DIST);
		this.x = initPos[0];
		this.y = initPos[1];
		
		/*
		this.x = this._oriPos[0];
		this.y = this._oriPos[1];
		*/

		//this.initShadow();
		this.initSprite();
		this.initNameLabel();
		this.initHpBar();

		this.standAct();
	}

	public release() {
		this.releaseSprite();
		this.clearEffect();
		this.clearSpAct();
	}

	public get id(): number {
		return this._id;
	}

	public getPos(): [number, number] {
		return [this.x, this.y];
	}

	public getOriPos(): [number, number] {
		return this._oriPos;
	}

	public getMoveDir(): [number, number] {
		return this._moveDir;
	}

	public get speed(): number {
		return this._speed;
	}

	public get group(): number {
		return this._group;
	}

	public get resType(): number {
		return this._resType;
	}

	public getAtkPos(tarId: number = 0): [number, number] {
		var offsetX = 0;
		var offsetY = 0;

		var tarObj: BattleObject = null;
		if(tarId > 0) {
			tarObj = this._battleLayer.getBattleObject(tarId);
		}
		
		if(this._resType == BattleObjResType.BORT_TANK && tarObj) {
			var srcCol = this.getCol();
			var tarCol = tarObj.getCol();
			if(srcCol == tarCol) {
				if(this._group == BattleObjGroup.BOG_A) {
					offsetX = this._battleObjCnf.atkOffsetA[0];
					offsetY = this._battleObjCnf.atkOffsetA[1];
				}
				else {
					offsetX = this._battleObjCnf.atkOffsetB[0];
					offsetY = this._battleObjCnf.atkOffsetB[1];
				}
			}
			else if(srcCol > tarCol) {
				if(this._group == BattleObjGroup.BOG_A) {
					offsetX = this._battleObjCnf.atkOffsetA[2];
					offsetY = this._battleObjCnf.atkOffsetA[3];
				}
				else {
					offsetX = this._battleObjCnf.atkOffsetB[2];
					offsetY = this._battleObjCnf.atkOffsetB[3];
				}
			}
			else {
				if(this._group == BattleObjGroup.BOG_A) {
					offsetX = this._battleObjCnf.atkOffsetA[4];
					offsetY = this._battleObjCnf.atkOffsetA[5];
				}
				else {
					offsetX = this._battleObjCnf.atkOffsetB[4];
					offsetY = this._battleObjCnf.atkOffsetB[5];
				}
			}
		}
		else {
			if(this._group == BattleObjGroup.BOG_A) {
				offsetX = this._battleObjCnf.atkOffsetA[0];
				offsetY = this._battleObjCnf.atkOffsetA[1];
			}
			else {
				offsetX = this._battleObjCnf.atkOffsetB[0];
				offsetY = this._battleObjCnf.atkOffsetB[1];
			}
		}

		offsetX = offsetX ? offsetX : 0;
		offsetY = offsetY ? offsetY : 0;

		return [this.x + offsetX * this._battleObjCnf.scale, this.y + offsetY * this._battleObjCnf.scale];
	}

	public getBeAtkedPos(): [number, number] {
		return [this.x, this.y + this._battleObjCnf.beatkedOffsetY];
	}

	public getCol(): number {
		return BattleUtil.getCol(this._standPos);
	}

	public getBeAtkedPriority(): number {
		return BattleUtil.getBeAtkedPriority(this._standPos);
	}

	public set hp(val: number) {
		this._hp = val;
	}

	public get hp(): number {
		return this._hp;
	}

	public set hpLim(val: number) {
		this._hpLim = val;
	}

	public get hpLim(): number {
		return this._hpLim;
	}

	/*
	protected initShadow(): void {
		this._shadow = new eui.Image(ResDataPath.GetAssets("image/other/yingzi"));
		this._shadow.anchorOffsetX = BattleObject.SHADOW_WIDTH / 2;
		this._shadow.anchorOffsetY = BattleObject.SHADOW_HEIGHT / 2;
		this.addChild(this._shadow);
	}
	*/

	protected initNameLabel(): void {
		this._nameLabel = new eui.Label(this._name);

		this._nameLabel.width = 100;
		this._nameLabel.height = 20;
		this._nameLabel.textAlign = 'center';
		this._nameLabel.size = 13;
		this._nameLabel.stroke = 1;
		this._nameLabel.strokeColor = 0x333333;
		this._nameLabel.anchorOffsetY = 60;
		this._nameLabel.anchorOffsetX = this._nameLabel.width / 2;
		this._nameLabel.verticalAlign = "bottom";
		this._nameLabel.scaleX = this._nameLabel.scaleY = 0.8;

		this.addChild(this._nameLabel);
	}

	protected initHpBar(): void {
		this._hpBar = new eui.ProgressBar();
		this._hpBar.skinName = "resource/eui_skins/progressBar/bar13Skin.exml";
		this._hpBar.width = 60;
        this._hpBar.height = 10;
        this._hpBar.minimum = 0;
        this._hpBar.maximum = this._hpLim;
		this._hpBar.value = this._hp;
		this._hpBar.anchorOffsetY = 40;
		this._hpBar.anchorOffsetX = this._hpBar.width / 2;
		this._hpBar.labelDisplay.visible = false;
		this._hpBar.scaleX = this._hpBar.scaleY = 0.8;
		this.addChild(this._hpBar);
	}

	public refreshHpBar(): void {
        this._hpBar.minimum = 0;
        this._hpBar.maximum = this._hpLim;
		this._hpBar.value = this._hp;
	}

	protected initSprite(): void {
		this._sprite = new MovieClip();
		this._sprite.scaleX = this._sprite.scaleY = this._battleObjCnf.scale;
		this.addChild(this._sprite);
	}

	protected releaseSprite(): void {
		this._sprite.stop();
		this._sprite.removeEventListener(egret.Event.CHANGE, this.onSpriteLoaded, this);
		this._sprite.DoDispose()
	}

	protected refreshSprite(): void {
		this._sprite.stop();
		this._sprite.addEventListener(egret.Event.CHANGE, this.onSpriteLoaded, this);
		
		this.loadFile(this._sprite, this._resType, this._resId, this._group, this._actionState);
	}

	protected onSpriteLoaded(event: any): void {
		this._sprite.removeEventListener(egret.Event.CHANGE, this.onSpriteLoaded, this);
		this._sprite.gotoAndPlay(1, -1);
	}


	protected loadFile(mc: MovieClip, resType: number, resId: number, group: number, state: number) {
		var strResType = BattleUtil.resType2Str(resType);
		var strFileName = BattleUtil.getResPath(group, resType, resId, state);

		mc.loadUrl(ResDataPath.GetMoviePath(strFileName, strResType));
	};

	public update(interval: number): void {
		this.updateEffect(interval);
		this.updateSpAct(interval);
	}

	public setActionState(state: number): void {
		if(this._actionState == state) {
			return;
		} 
		this._actionState = state;

		this.refreshSprite();
	}

	public standAct(): void {
		if(this._group == BattleObjGroup.BOG_A) {
			this.setActionState(BattleObjActSt.BOAS_STAND_A);
		}
		else {
			this.setActionState(BattleObjActSt.BOAS_STAND_B);
		}
	}

	public runAct(): void {
		if(this._group == BattleObjGroup.BOG_A) {
			this.setActionState(BattleObjActSt.BOAS_RUN_A);
		}
		else {
			this.setActionState(BattleObjActSt.BOAS_RUN_B);
		}
	}

	public attackAct(): void {
		if(this._group == BattleObjGroup.BOG_A) {
			this.setActionState(BattleObjActSt.BOAS_ATTACK_A);
		}
		else {
			this.setActionState(BattleObjActSt.BOAS_ATTACK_B);
		}
	}

	public attackUpAct(): void {
		if(this._group == BattleObjGroup.BOG_A) {
			this.setActionState(BattleObjActSt.BOAS_ATKUP_A);
		}
		else {
			this.setActionState(BattleObjActSt.BOAS_ATKUP_B);
		}
	}

	public attackDownAct(): void {
		if(this._group == BattleObjGroup.BOG_A) {
			this.setActionState(BattleObjActSt.BOAS_ATKDOWN_A);
		}
		else {
			this.setActionState(BattleObjActSt.BOAS_ATKDOWN_B);
		}
	}

	public dieAct(): void {
		if(this._group == BattleObjGroup.BOG_A) {
			this.setActionState(BattleObjActSt.BOAS_DIE_A);
		}
		else {
			this.setActionState(BattleObjActSt.BOAS_DIE_B);
		}
	}

	public getDir(): number {
		return this._group == BattleObjGroup.BOG_A ? BattleObjDir.BOD_RIGHT : BattleObjDir.BOD_LEFT;
	}

	public createEffect(effId: number, x: number, y: number, z: number, life: number): MovieClip {
		var effect = new MovieClip();
		effect.x = x;
		effect.y = y;
		effect.loadUrl(ResDataPath.GetSkillEffPathByID(effId), true);
		this.addChild(effect);

		this._effectDatas.push({
			effId: effId,
			x: x,
			y: y,
			z: z,
			life: life,
			effect: effect
		});

		return effect;
	}

	public updateEffect(interval: number): void {
		for(var i in this._effectDatas) {
			var effectData = this._effectDatas[i];
			effectData.life -= interval;
			if(effectData.life < 0) {
				var effect = effectData.effect;
				if(effect && effect.parent) {
					effect.parent.removeChild(effect);
				}

				this._effectDatas.splice(i, 1);

				break;
			}
		}
	}

	public clearEffect(): void {
		for(var i in this._effectDatas) {
			var effectData = this._effectDatas[i];
			var effect = effectData.effect;
			if(effect && effect.parent) {
				effect.parent.removeChild(effect);
			}
		}
		this._effectDatas = [];
	}

	public playSkillAct(skill_act_id: number, def_list: any): void {
		var skillActCnf = SkillActCnf[skill_act_id];
		for(var i in skillActCnf.particle) {
			var particleData = skillActCnf.particle[i];
			this.addSpAct(particleData[0], BattleObjSpAct.BOSA_PARTICLE, particleData, null);
		}

		for(var i in skillActCnf.sound) {
			var soundData = skillActCnf.sound[i];
			this.addSpAct(soundData[0], BattleObjSpAct.BOSA_SOUND, soundData, null);
		}
		
		var multi_tick = 0;
		var state = 0;
		for(var def_idx in def_list) {
			var battle_def = def_list[def_idx];
			var tarObj = this._battleLayer.getBattleObject(battle_def.def_id);

			if(skillActCnf.atk_mode == BattleAtkMode.BAM_PER_WEAPON) {
				if(this._battleObjCnf.resType == BattleObjResType.BORT_TANK) {
					state = BattleUtil.getStActByCol(BattleObject.ATK_ACT_STS, 
						this.group, this.getCol(),
						tarObj.group, tarObj.getCol());
				}
				else {
					state = this._group == BattleObjGroup.BOG_A ? 
						BattleObjActSt.BOAS_ATTACK_A: 
						BattleObjActSt.BOAS_ATTACK_B;
				}
				this.addSpAct(multi_tick - 0.2, BattleObjSpAct.BOSA_ACTIONSTATE, state, null);
			}

			if(skillActCnf.weapon_type == WeaponType.WT_BULLET) {
				this.addSpAct(0 + multi_tick, BattleObjSpAct.BOSA_BULLET, skillActCnf.weapon_id, battle_def);
			}
			else if(skillActCnf.weapon_type == WeaponType.WT_MACHINEGUN) {
				this.addSpAct(0 + multi_tick, BattleObjSpAct.BOSA_MACHINEGUN, skillActCnf.weapon_id, battle_def);
			}
			
			if(skillActCnf.recoil) {
				this.addSpAct(multi_tick, BattleObjSpAct.BOSA_RECOIL, null, null);
			}

			multi_tick += skillActCnf.multiInterval;
		}

		if(skillActCnf.atk_mode == BattleAtkMode.BAM_PER_SKILL) {
			state = this._group == BattleObjGroup.BOG_A ? 
						BattleObjActSt.BOAS_ATTACK_A: 
						BattleObjActSt.BOAS_ATTACK_B;
			this.addSpAct(multi_tick - 0.2, BattleObjSpAct.BOSA_ACTIONSTATE, state, null);
		}

		if(skillActCnf.atk_mode == BattleAtkMode.BAM_PER_SKILL ||
			skillActCnf.atk_mode == BattleAtkMode.BAM_PER_WEAPON) {
			this.addSpAct(skillActCnf.multiInterval * def_list.length + 0.5,
				BattleObjSpAct.BOSA_STAND, 
				null, null);
		}

		if(skillActCnf.atkEffA > 0 && skillActCnf.atkEffB) {
			var effId = this._group == BattleObjGroup.BOG_A ? 
				skillActCnf.atkEffA : 
				skillActCnf.atkEffB;

			var atkPos = this.getAtkPos();
			this.createEffect(effId, atkPos[0], atkPos[1], 0, 1);
		}

		if(skillActCnf.atkSound > 0) {
			SoundMgr.getInstance().playSound(skillActCnf.atkSound);
		}
	}

	public calcSkillActTime(skill_act_id: number, def_list: any): number {
		var skillActCnf = SkillActCnf[skill_act_id];

		var time = def_list.length * skillActCnf.multiInterval;

		if(skillActCnf.weapon_type == WeaponType.WT_BULLET) {
			var bulletCnf = BulletCnf[skillActCnf.weapon_id];
			if(bulletCnf.trackType == BulletTrack.BT_LINEAR 
				|| bulletCnf.trackType == BulletTrack.BT_BEZIERAT2) {

				var def_id = def_list[def_list.length - 1].def_id;
				var defObj = this._battleLayer.getBattleObject(def_id);
				var dist = VectorUtil.calcLength(defObj.x - this.x, defObj.y - this.y);

				time += dist / bulletCnf.speed;

			}
		}
		else if(skillActCnf.weapon_type == WeaponType.WT_MACHINEGUN) {
			var machineGunCnf = MachineGunCnf[skillActCnf.weapon_id];

			time += machineGunCnf.life;
		}
		
		
		return time;	
	}

	protected playSpAct_PARTICLE(data: any, battle_def: any): void {
		var effType = data[1];
		var effId = data[2];
		var x = data[3];
		var y = data[4];
		var z = data[5];
		var rotation = data[6];
		var life = data[7];

		if(effType == BattleEffType.BET_SELF) {
			this.createEffect(effId, x, y, z, life);

		} else if(effType == BattleEffType.BET_TAR) {
			var tarId = battle_def.def_id;
			var tarObj = this._battleLayer.getBattleObject(tarId);
			tarObj.createEffect(effId, x, y, z, life);

		} else if(effType == BattleEffType.BET_MAP) {
			this._battleLayer.createEffect(effId, this.x + x, this.y + y, z, life);

		}
	}

	protected playSpAct_BULLET(data: any, battle_def: any): void {
		var bulletId = data;
		
		var srcId = this.id;
		var tarId = battle_def.def_id;

		this._battleLayer.createBullet(srcId, tarId, bulletId, battle_def);
	}

	protected playSpAct_MACHINEGUN(data: any, battle_def: any): void {
		var machineGunId = data;
		
		var srcId = this.id;
		var tarId = battle_def.def_id;

		this._battleLayer.createMachineGun(srcId, tarId, machineGunId, battle_def);
	}

	protected playSpAct_ACTIONSTATE(data: any): void {
		var state = data;
		
		this.setActionState(state);
	}

	protected playSpAct_RECOIL(data: any): void {
		this.playRecoilAct();
	}

	protected playSpAct_SOUND(data: any): void {
		var soundId = data[1];
		SoundMgr.getInstance().playSound(soundId);
	}

	protected playSpAct_STAND(data: any): void {
		this.standAct();
	}

	protected playSpAct(spAct: any): void {
		var type = spAct.type;
		var data = spAct.data;
		var param = spAct.param;
		switch(type) {
			case BattleObjSpAct.BOSA_PARTICLE:
				this.playSpAct_PARTICLE(data, param);
				break;
			case BattleObjSpAct.BOSA_BULLET:
				this.playSpAct_BULLET(data, param);
				break;
			case BattleObjSpAct.BOSA_MACHINEGUN:
				this.playSpAct_MACHINEGUN(data, param);
				break;
			case BattleObjSpAct.BOSA_ACTIONSTATE:
				this.playSpAct_ACTIONSTATE(data);
				break;
			case BattleObjSpAct.BOSA_RECOIL:
				this.playSpAct_RECOIL(data);
				break;
			case BattleObjSpAct.BOSA_SOUND:
				this.playSpAct_SOUND(data);
				break;
			case BattleObjSpAct.BOSA_STAND:
				this.playSpAct_STAND(data);
				break;
		}
	}

	protected addSpAct(time, type, data, param): void {
		this._spActs.push({
			time: time,
			type: type,
			data: data,
			param: param
		});
	}

	protected updateSpAct(interval: number): void {
		for(var i in this._spActs) {
			var spAct = this._spActs[i];
			spAct.time = spAct.time - interval;
		}

		for(var i in this._spActs) {
			var spAct = this._spActs[i];
			if(spAct.time <= 0) {
				this._spActs.splice(i, 1);
				this.playSpAct(spAct);
				break;
			}
		}
	}

	protected clearSpAct(): void {
		this._spActs = [];
	}

	public execSkill(roundData: any): void {
		var skill_id = roundData.skill_id;
		var skill_level = roundData.skill_level;
		var att_attr_change = roundData.att_attr_change;
		var att_del_buff = roundData.att_del_buff;
		var att_add_buff = roundData.att_add_buff;
		var def_list = roundData.def_list;

		var skillCnf = SkillCnf[skill_id];
		var skill_act_id = skillCnf.skill_act_id[0];
		if(this._group == BattleObjGroup.BOG_B && skillCnf.skill_act_id[1]) {
			skill_act_id = skillCnf.skill_act_id[1];
		}

		var proi_def_list = def_list.slice(0);
		proi_def_list.sort((def1, def2) => {
			var defObj1 = this._battleLayer.getBattleObject(def1.def_id);
			var defObj2 = this._battleLayer.getBattleObject(def2.def_id);
			var p1 = defObj1.getBeAtkedPriority();
			var p2 = defObj2.getBeAtkedPriority();
			return p1 > p2;
		});
		this.playSkillAct(skill_act_id, proi_def_list);

		if(att_attr_change.length > 0) {
			for(var i = 0; i < att_attr_change.length; ++i) {
				var attr = att_attr_change[i];
				if(attr.attr_id == BattleAttrID.BAID_HP) {
					this.hp = attr.attr_value;
				}
			}
			this.refreshHpBar();
			this._battleLayer.playAttAttrChangeEff(this.id, att_attr_change);
		}

		for(var i = 0; i < def_list.length; ++i) {
			var def_data = def_list[i];
			var def_id = def_data.def_id;
			var hit_status = def_data.hit_status;
			var defObj = this._battleLayer.getBattleObject(def_id);
			if(defObj) {
				for(var j = 0; j < def_data.def_attr_change.length; ++j) {
					var attr = def_data.def_attr_change[j];
					if(attr.attr_id == BattleAttrID.BAID_HP) {
						//todo:now for test
						//defObj.hp = attr.attr_value;
						defObj.hp += attr.delta_value;
					}
				}
			}
			else {
				console.error("BattleObject_execSkill invalid defObj", JSON.stringify(def_data));
			}
		}
	}

	public calcSkillTime(roundData: any): number {
		var skill_id = roundData.skill_id;
		var skill_level = roundData.skill_level;
		var att_attr_change = roundData.att_attr_change;
		var att_del_buff = roundData.att_del_buff;
		var att_add_buff = roundData.att_add_buff;
		var def_list = roundData.def_list;

		var skillCnf = SkillCnf[skill_id];
		var skill_act_id = skillCnf.skill_act_id[0];

		return this.calcSkillActTime(skill_act_id, def_list);
	}

	protected playRecoilAct(): void  {
		var dist = 3;
		var tick = 50;
		egret.Tween.get(this._sprite).to({x: - this._moveDir[0] * dist, y: - this._moveDir[1] * dist}, tick)
			.to({x: 0, y: 0}, 
			tick);
	}

	public playBeAtkedAct(): void {
		var dist = 3;
		var tick = 50;
		egret.Tween.get(this._sprite).to({x: - this._moveDir[0] * dist, y: - this._moveDir[1] * dist}, tick)
			.to({x: 0, y: 0}, 
			tick);
	}

	public isDead(): boolean {
		return this._isDead;
	}

	public die(): void  {
		if(this._isDead) {
			return;
		}
		this._isDead = true;

		this.dieAct();

		if(this._battleObjCnf.dieEffId > 0) {
			this.createEffect(this._battleObjCnf.dieEffId, 0, 0, 0, 1);
		}

		if(this._battleObjCnf.dieSoundId > 0) {
			SoundMgr.getInstance().playSound(this._battleObjCnf.dieSoundId);
		}
	}

	public playEnterAct(): void {
		if(this._battleObjCnf.enterSoundId > 0) {
			SoundMgr.getInstance().playSound(this._battleObjCnf.enterSoundId);
		}
	}

	public onEnterUpdate(interval: number): void {
		var footprint = null;
		if(this._group == BattleObjGroup.BOG_A) {
			footprint = this._battleObjCnf.footprintA;
		}
		else {
			footprint = this._battleObjCnf.footprintB;
		}
		if(footprint) {
			var imgId = footprint[0];
			var tick = footprint[1];
			var x = footprint[2];
			var y = footprint[3];
			var scale = footprint[4];

			this._footprintTick -= interval;
			if(this._footprintTick <= 0) {
				this._footprintTick = tick;
				this._battleLayer.createFootprint(imgId, 
					this.x + x, this.y + y, 
					this._battleObjCnf.scale * scale);
			}
		}
	}
}