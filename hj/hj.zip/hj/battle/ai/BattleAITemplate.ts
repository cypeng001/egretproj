class BattleAITemplate {
	private static _template_SOILDER(temp_param: any): any {
		return {
			init_state: BattleAIState.BAS_ENTER,
			init_st_data: ["test01"],
			fsm: {
				[BattleAIState.BAS_ENTER]: [
					{
						next_st: BattleAIState.BAS_PREPARE, next_st_data: ["test04"], 
						cond_type: BattleAIEvent.BAE_END_ENTER, cond_data: null, 
					},
				],
				[BattleAIState.BAS_PREPARE]: [
					/*
					{
						next_st: BattleAIState.BAS_MOVE, next_st_data: ["test02"], 
						cond_type: BattleAIEvent.BAE_END_PREPARE, cond_data: null, 
					},
					*/
					{
						next_st: BattleAIState.BAS_PREPARE, next_st_data: ["test02"], 
						cond_type: BattleAIEvent.BAE_END_PREPARE, cond_data: null, 
					},
				],
				[BattleAIState.BAS_MOVE]: [
					{
						next_st: BattleAIState.BAS_PREPARE, next_st_data: ["test03"], 
						cond_type: BattleAIEvent.BAE_END_MOVE, cond_data: null,
					},
				],
			}
		}
	}

	public static genAIFSM(id: number, temp_param: any): any {
		switch(id) {
			case BattleAITempType.BAITT_SOILDER: {
				return BattleAITemplate._template_SOILDER(temp_param);
			}
		}
	}
}