class BattleAIFactory {
	private _ai_datas: any = {};

	public static _instance: BattleAIFactory = null;

	public static getInstance(): BattleAIFactory {
		if(!BattleAIFactory._instance) {
			BattleAIFactory._instance = new BattleAIFactory();
		}
		return BattleAIFactory._instance;
	}

	public constructor() {

	}

	public getAI(id): any {
		var ai_data = this._ai_datas[id];
		if(ai_data) {
			return ai_data;
		}

		var ai_cnf = BattleAICnf[id];
		if(!ai_cnf) {
			console.warn("BattleAIFactory.getAI ai_cnf invalid", id);
		}

		this._ai_datas[id] = BattleAITemplate.genAIFSM(ai_cnf.temp_type, ai_cnf.temp_param);

		return this._ai_datas[id];
	}

	public hasAIState = function(id, state) {
		var ai_data = this.getAI(id);
		if(!ai_data) {
			return false;
		}

		return ai_data.fsm[state] ? true : false
	}
}