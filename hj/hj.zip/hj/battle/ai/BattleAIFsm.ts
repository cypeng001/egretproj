class BattleAIFsm {
	public static _instance: BattleAIFsm = null;

	public static getInstance(): BattleAIFsm {
		if(!BattleAIFsm._instance) {
			BattleAIFsm._instance = new BattleAIFsm();
		}
		return BattleAIFsm._instance;
	}

	private _checkEventFunc: any = {};

	public constructor() {
		this._checkEventFunc[BattleAIEvent.BAE_END_ENTER] = BattleAIFsm.checkEvent_END_ENTER;
		this._checkEventFunc[BattleAIEvent.BAE_END_EXIT] = BattleAIFsm.checkEvent_END_EXIT;
		this._checkEventFunc[BattleAIEvent.BAE_END_IDLE] = BattleAIFsm.checkEvent_END_IDLE;
		this._checkEventFunc[BattleAIEvent.BAE_END_PREPARE] = BattleAIFsm.checkEvent_END_PREPARE;
		this._checkEventFunc[BattleAIEvent.BAE_END_ATK] = BattleAIFsm.checkEvent_END_ATK;
		this._checkEventFunc[BattleAIEvent.BAE_END_BEATKED] = BattleAIFsm.checkEvent_END_BEATKED;
		this._checkEventFunc[BattleAIEvent.BAE_END_MOVE] = BattleAIFsm.checkEvent_END_MOVE;
	}

	public static checkEvent_END_ENTER(cond_data, event_data): boolean {
		return true;
	}

	public static checkEvent_END_EXIT(cond_data, event_data): boolean {
		return true;
	}

	public static checkEvent_END_IDLE(cond_data, event_data): boolean {
		return true;
	}

	public static checkEvent_END_PREPARE(cond_data, event_data): boolean {
		return true;
	}

	public static checkEvent_END_ATK(cond_data, event_data): boolean {
		return true;
	}

	public static checkEvent_END_BEATKED(cond_data, event_data): boolean {
		return true;
	}

	public static checkEvent_END_MOVE(cond_data, event_data): boolean {
		return true;
	}

	private static _weightRandom(list: any): any {
		var total = 0
		for(var k in list) {
			var v = list[k];
			total += v.weight;
		}

		var rand = MathUtil.randInRange(0, total - 1);

		total = 0
		for(var k in list) {
			var v = list[k];
			total = total + v.weight;
			if(total >= rand) {
				return v;
			}
		}

		return list[0];
	}

	public stateTrans(id: number, state: number, event_type: number, event_data: any): any {
		var ai_data = BattleAIFactory.getInstance().getAI(id);
		if(!ai_data) {
			console.warn("BattleAIFsm.stateTrans invalid ai_data", id, state, event_type);
			return;
		}

		var fsm_cnf = ai_data.fsm[state]
		if (!fsm_cnf) {
			console.warn("BattleAIFsm.stateTrans invalid fsm_cnf", id, state, event_type);
			return;
		}

		var st_list = [];

		for(var k in fsm_cnf) {
			var v = fsm_cnf[k];
			if(v.cond_type == event_type) {
				var func = this._checkEventFunc[event_type];
				if(!func) {
					console.warn("BattleAIFsm.stateTrans invalid func", id, state, event_type);
					return;
				}

				var ret = func(v.cond_data, event_data);

				if(ret) {
					var weight = v.weight || 1;
					st_list.push({
						st: v.next_st, 
						st_data: v.next_st_data, 
						weight: weight
					});
				}
			}

			
		}

		if(st_list.length > 0) {
			var ret = BattleAIFsm._weightRandom(st_list);
			return [ret.st, ret.st_data];
		}

		return null;
	}
}