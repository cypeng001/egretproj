var BattleAICnf = {
	1: {
		temp_type: 1001,
		temp_param: [100],
	}
}