enum BattleAIState {
	BAS_NONE		= 0,
	BAS_ENTER		= 1,
	BAS_EXIT		= 2,
	BAS_IDLE		= 3,
	BAS_PREPARE		= 4,
	BAS_ATK			= 5,
	BAS_BEATKED		= 6,
	BAS_MOVE		= 7,
};

enum BattleAIEvent {
	BAE_END_ENTER		= 1,
	BAE_END_EXIT		= 2,
	BAE_END_IDLE		= 3,
	BAE_END_PREPARE		= 4,
	BAE_END_ATK			= 5,
	BAE_END_BEATKED		= 6,
	BAE_END_MOVE		= 7,
}

enum BattleAITempType {
	BAITT_SOILDER		= 1001,
}