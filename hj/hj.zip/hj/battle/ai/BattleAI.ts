class BattleAI extends egret.EventDispatcher {
	private _battleLayer: BattleLayer;
	private _battleObject: BattleObject;

	private id: number = 0;

	private cur_state: number = 0;
	private cur_st_data: any = null;
	private next_state: number = 0;
	private next_st_data: any = null;

	private _tick: number = 0;
	private _time: number = 0;
	private _speed: [number, number] = [0, 0];
	private _tarPos: [number, number] = [0, 0];

	public constructor() {
		super();
	}

	public init(battleLayer: BattleLayer, battleObject: BattleObject): void {
		this._battleLayer = battleLayer;
		this._battleObject = battleObject;

		this.cur_state = BattleAIState.BAS_NONE;
		this.cur_state = BattleAIState.BAS_NONE;
	}

	public release(): void {
		this._battleLayer = null;
		this._battleObject = null;
	}

	public update(interval: number): void {
		if(this.id <= 0) {
			return;
		}
		this.updateState(interval);
	}

	public loadAI(id: number): void {
		this.id = id;
		this.initAIParam();

		var ai_data = BattleAIFactory.getInstance().getAI(this.id);
		this.setNextState(ai_data.init_state, ai_data.init_st_data);
	}

	public initAIParam(): void {
		var ai_cnf = BattleAICnf[this.id];
		if(ai_cnf.temp_id == BattleAITempType.BAITT_SOILDER) {

		}
	}

	public setNextState(next_state, next_st_data): void {
		this.next_state = next_state;
		this.next_st_data = next_st_data;
	}

	public setNextAIStByEvent(aifsm_event: number, aifsm_event_data: any = null) {
		var next_st = BattleAIFsm.getInstance().stateTrans(this.id, this.cur_state, aifsm_event, aifsm_event_data);
		if(next_st) {
			var next_state = next_st[0];
			var next_st_data = next_st[1];
			this.setNextState(next_state, next_st_data);
		}
		else {
			console.warn("BattleAI.setNextAIStByEvent next_st invalid", this.id, this.cur_state, aifsm_event);
		}
	}

	private popNextState(): any {
		if(!this.next_state) {
			return null;
		}

		var next_state = this.next_state;
		var next_st_data = this.next_st_data;

		this.next_state = BattleAIState.BAS_NONE;
		this.next_st_data = null;

		return [next_state, next_st_data];
	}

	public updateState(interval: number): void {
		if (this.cur_state == BattleAIState.BAS_NONE 
			&& this.next_state == BattleAIState.BAS_NONE) {
			return;
		}

		var next_st = this.popNextState();
		if(next_st && next_st[0] != BattleAIState.BAS_NONE) {
			var next_state = next_st[0];
			var next_st_data = next_st[1];

			this.exitState(this.cur_state, next_state);
			this.enterState(next_state, next_st_data);
			this.cur_state = next_state;
			this.cur_st_data = next_st_data;
		}
		else {
			this._updateState(this.cur_state, interval);
		}
	}

	public enterState(next_state, next_st_data): void {
		if (next_state == BattleAIState.BAS_NONE) {
			return;
		}

		switch(next_state) {
			case BattleAIState.BAS_ENTER: {
				this._enterState_ENTER(next_st_data);
				break;
			}
			case BattleAIState.BAS_EXIT: {
				this._enterState_EXIT(next_st_data);
				break;
			}
			case BattleAIState.BAS_IDLE: {
				this._enterState_IDLE(next_st_data);
				break;
			}
			case BattleAIState.BAS_PREPARE: {
				this._enterState_PREPARE(next_st_data);
				break;
			}
			case BattleAIState.BAS_ATK: {
				this._enterState_ATK(next_st_data);
				break;
			}
			case BattleAIState.BAS_BEATKED: {
				this._enterState_BEATKED(next_st_data);
				break;
			}
			case BattleAIState.BAS_MOVE: {
				this._enterState_MOVE(next_st_data);
				break;
			}
		}
	}

	public exitState(cur_state, next_state): void {
		if(cur_state == BattleAIState.BAS_NONE) {
			return;
		}

		switch(cur_state) {
			case BattleAIState.BAS_ENTER: {
				this._exitState_ENTER(next_state);
				break;
			}
			case BattleAIState.BAS_EXIT: {
				this._exitState_EXIT(next_state);
				break;
			}
			case BattleAIState.BAS_IDLE: {
				this._exitState_IDLE(next_state);
				break;
			}
			case BattleAIState.BAS_PREPARE: {
				this._exitState_PREPARE(next_state);
				break;
			}
			case BattleAIState.BAS_ATK: {
				this._exitState_ATK(next_state);
				break;
			}
			case BattleAIState.BAS_BEATKED: {
				this._exitState_BEATKED(next_state);
				break;
			}
			case BattleAIState.BAS_MOVE: {
				this._exitState_MOVE(next_state);
				break;
			}
		}
	}

	private _updateState(state, interval) : void {
		if(state == BattleAIState.BAS_NONE) {
			return;
		}

		switch(state) {
			case BattleAIState.BAS_ENTER: {
				this._updateState_ENTER(interval);
				break;
			}
			case BattleAIState.BAS_EXIT: {
				this._updateState_EXIT(interval);
				break;
			}
			case BattleAIState.BAS_IDLE: {
				this._updateState_IDLE(interval);
				break;
			}
			case BattleAIState.BAS_PREPARE: {
				this._updateState_PREPARE(interval);
				break;
			}
			case BattleAIState.BAS_ATK: {
				this._updateState_ATK(interval);
				break;
			}
			case BattleAIState.BAS_BEATKED: {
				this._updateState_BEATKED(interval);
				break;
			}
			case BattleAIState.BAS_MOVE: {
				this._updateState_MOVE(interval);
				break;
			}
		}
	}

	private _enterState_ENTER(next_st_data: any): void {
		this._tick = 0;
		this._time = 1;

		var pos = this._battleObject.getPos();
		var oriPos = this._battleObject.getOriPos();
		var speed = this._battleObject.speed;

		this._tarPos = oriPos;
		
		this._time = BattleUtil.calcTime(pos[0], pos[1], oriPos[0], oriPos[1], speed);
		this._speed = BattleUtil.calcSpeed(pos[0], pos[1], oriPos[0], oriPos[1], speed);

		this._battleObject.playEnterAct();
	}

	private _updateState_ENTER(interval): void {
		this._tick += interval;

		this._battleObject.x += this._speed[0] * interval;
		this._battleObject.y += this._speed[1] * interval;

		this._battleObject.onEnterUpdate(interval);

		if(this._tick > this._time) {
			this._battleObject.x = this._tarPos[0];
			this._battleObject.y = this._tarPos[1];
			
			this.setNextAIStByEvent(BattleAIEvent.BAE_END_ENTER);
		}
	}

	private _exitState_ENTER(next_state: number): void {

	}

	private _enterState_EXIT(next_st_data: any): void {
		this._tick = 0;
		this._time = 1;
	}

	private _updateState_EXIT(interval): void {
		this._tick += interval;
		if(this._tick > this._time) {
			this.setNextAIStByEvent(BattleAIEvent.BAE_END_EXIT);
		}
	}

	private _exitState_EXIT(next_state: number): void {

	}

	private _enterState_IDLE(next_st_data: any): void {
		this._tick = 0;
		this._time = 1;
	}

	private _updateState_IDLE(interval): void {
		this._tick += interval;
		if(this._tick > this._time) {
			this.setNextAIStByEvent(BattleAIEvent.BAE_END_IDLE);
		}
	}

	private _exitState_IDLE(next_state: number): void {

	}

	private _enterState_ATK(next_st_data: any): void {
		this._tick = 0;
		this._time = 1;
	}

	private _updateState_ATK(interval): void {
		this._tick += interval;
		if(this._tick > this._time) {
			this.setNextAIStByEvent(BattleAIEvent.BAE_END_ATK);
		}
	}

	private _exitState_ATK(next_state: number): void {

	}

	private _enterState_BEATKED(next_st_data: any): void {
		this._tick = 0;
		this._time = 1;
	}

	private _updateState_BEATKED(interval): void {
		this._tick += interval;
		if(this._tick > this._time) {
			this.setNextAIStByEvent(BattleAIEvent.BAE_END_BEATKED);
		}
	}

	private _exitState_BEATKED(next_state: number): void {

	}

	private _enterState_PREPARE(next_st_data: any): void {
		this._tick = 0;
		this._time = 1;
	}

	private _updateState_PREPARE(interval): void {
		this._tick += interval;
		if(this._tick > this._time) {
			this.setNextAIStByEvent(BattleAIEvent.BAE_END_PREPARE);
		}
	}

	private _exitState_PREPARE(next_state: number): void {

	}

	private _enterState_MOVE(next_st_data: any): void {
		this._tick = 0;
		this._time = 1;
	}

	private _updateState_MOVE(interval): void {
		this._tick += interval;
		if(this._tick > this._time) {
			this.setNextAIStByEvent(BattleAIEvent.BAE_END_MOVE);
		}
	}

	private _exitState_MOVE(next_state: number): void {

	}
}