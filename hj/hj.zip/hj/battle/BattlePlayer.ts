class BattlePlayer extends egret.EventDispatcher {
	private static MAX_ROUND_TICK = 3;

	private _battleLayer: BattleLayer = null;
	private _battleResult: any = null;
	private _tick: number = 0;
	private _roundIdx: number = 0;
	private _roundList: any = [];

	public init(battleLayer: BattleLayer, battleResult: any): void {
		this._battleLayer = battleLayer;
		this._battleResult = battleResult;

		this._tick = BattleObject.DEF_ENTER_STAGE_DIST / BattleObject.DEF_SPEED;

		for(var reportIdx = 0; reportIdx < battleResult.battleReport.length; ++reportIdx) {
			var reportData = battleResult.battleReport[reportIdx];
			for(var roundIdx = 0; roundIdx < reportData.one_round_data.length; ++roundIdx) {
				var roundData = reportData.one_round_data[roundIdx];
				this._roundList.push(roundData);
			}
		}
	}

	public release(): void {
		this._battleResult = null;
		this._battleResult = null;
		this._roundList = null;
	}

	private endBattle(): void {

	}

	public update(interval): void {
		this._tick = this._tick - interval;
		if(this._tick > 0) {
			return;
		}
		this._tick = BattlePlayer.MAX_ROUND_TICK;

		if(this._roundIdx < this._roundList.length) {
			this.playRound(this._roundList[this._roundIdx++]);
		}
		else {
			this.endBattle();
		}
	}

	public playRound(roundData: any): void {
		var atkObj = this._battleLayer.getBattleObject(roundData.att_id);
		if(!atkObj) {
			console.error("BattlePlayer_playRound invalid atkObj", JSON.stringify(roundData));
			return;
		}

		atkObj.execSkill(roundData);

		this._tick = Math.min(BattlePlayer.MAX_ROUND_TICK, atkObj.calcSkillTime(roundData));
	}
}