enum BattleObjActSt {
    BOAS_STAND_A		= 1,
    BOAS_STAND_B	    = 2,

	BOAS_RUN_A	    = 3,
	BOAS_RUN_B	        = 4,

	BOAS_ATTACK_A	    = 5,
	BOAS_ATTACK_B	    = 6,

	BOAS_ATKUP_A	    = 7,
	BOAS_ATKUP_B	    = 8,

	BOAS_ATKDOWN_A	    = 9,
	BOAS_ATKDOWN_B	    = 10,

	BOAS_DIE_A	    = 11,
	BOAS_DIE_B	        = 12,
};

enum BattleObjDir {
	BOD_LEFT			= 1,
	BOD_RIGHT			= 2,
};

enum BattleObjResType {
	BORT_TANK			= 1,
	BORT_MISSILE		= 2,
	BORT_SOLDIER		= 3,
	BORT_HELICOPTER		= 4,
};

enum BattleObjGroup {
	BOG_A			= 1,
	BOG_B			= 2,
};

enum BattleObjSpAct {
	BOSA_PARTICLE		= 1,
	BOSA_BULLET			= 2,
	BOSA_ACTIONSTATE	= 3,
	BOSA_RECOIL			= 4,
	BOSA_SOUND			= 5,
	BOSA_MACHINEGUN		= 6,
	BOSA_STAND			= 7,
};

enum BattleEffType {
	BET_SELF		= 1,
	BET_TAR			= 2,
	BET_MAP			= 3,
};

enum BattleAttrID {
	BAID_HP		= 1,
};

enum BattleHitStatus {
	BHS_NORMAL		= 1,
	BHS_CRIT		= 2,
	BHS_MISS		= 3,
};

enum BattleAtkMode {
	BAM_NONE		= 0,
	BAM_PER_SKILL	= 1,
	BAM_PER_WEAPON	= 2,
}