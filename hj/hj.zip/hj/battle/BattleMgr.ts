class BattleMgr extends BaseSystem {
	public constructor() {
		super();

		Sproto.SprotoReceiver.AddHandler(S2cProtocol.sc_battle_report, this.onBattleRequestResp, this);
	}

	public static ins(): BattleMgr {
		return super.ins();
	}

	public reqBattleRequest(type: number, targetId: number) : void {
		let battle_request = new Sproto.cs_battle_request_request();
		battle_request.type = type;
		battle_request.targetId = targetId;
		GameSocket.ins().Rpc(C2sProtocol.cs_battle_request, battle_request);
	}

	public onBattleRequestResp(data: Sproto.sc_battle_report_request) : void {

	}

}