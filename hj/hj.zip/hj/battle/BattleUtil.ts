class BattleUtil {
	private static _res_path_cache: any = {};

	public static resType2Str(resType: number): string {
		if(resType == BattleObjResType.BORT_TANK) {
			return "tank";
		}
		else if(resType == BattleObjResType.BORT_MISSILE) {
			return "missile";
		}
		else if(resType == BattleObjResType.BORT_SOLDIER) {
			return "soldier";
		}
		else if(resType == BattleObjResType.BORT_HELICOPTER) {
			return "helicopter";
		}
		return "";
	}

	private static state2Str(resType: number, state: number): string {
		if(resType == BattleObjResType.BORT_TANK) {
			if(state == BattleObjActSt.BOAS_ATKUP_A || state == BattleObjActSt.BOAS_ATKUP_B)
			{
				return "atkup";
			}
			if(state == BattleObjActSt.BOAS_ATKDOWN_A || state == BattleObjActSt.BOAS_ATKDOWN_B)
			{
				return "atkdown";
			}
			if(state == BattleObjActSt.BOAS_DIE_A || state == BattleObjActSt.BOAS_DIE_B)
			{
				return "die";
			}

			return "stand"
		}
		if(resType == BattleObjResType.BORT_MISSILE) {
			if(state == BattleObjActSt.BOAS_ATTACK_A || state == BattleObjActSt.BOAS_ATTACK_B)
			{
				return "attack";
			}

			return "stand"
		}
		else {
			if(state == BattleObjActSt.BOAS_STAND_A || state == BattleObjActSt.BOAS_STAND_B)
			{
				return "stand";
			}
			if(state == BattleObjActSt.BOAS_RUN_A || state == BattleObjActSt.BOAS_RUN_B)
			{
				return "run";
			}
			if(state == BattleObjActSt.BOAS_ATTACK_A || state == BattleObjActSt.BOAS_ATTACK_B)
			{
				return "attack";
			}
			if(state == BattleObjActSt.BOAS_DIE_A || state == BattleObjActSt.BOAS_DIE_B)
			{
				return "die";
			}
		}
		
		return "stand";
	}

	private static group2Str(group: number): string {
		if(group == BattleObjGroup.BOG_A) {
			return "1";
		}
		else {
			return "2";
		}
	}

	public static getResPath(group: number, resType: number, resId: number, state: number): string {
		var key = group * 10000000 + resType * 1000000 + resId * 100 + state;
		var ret = BattleUtil._res_path_cache[key];
		if(ret) {
			return ret;
		}

		var strResType = BattleUtil.resType2Str(resType);
		var strGroup = BattleUtil.group2Str(group);
		var strState = BattleUtil.state2Str(resType, state);

		ret = strResType + "_" + resId + "_" + strGroup + "_" + strState;
		BattleUtil._res_path_cache[key] = ret;
		return ret;
	}

	
	private static _stand_pos_cache: any = null;

	private static initPos(): void {
		if(BattleUtil._stand_pos_cache) {
			return;
		}

		var row = 3;
		var col = 2;

		var _group_a_ori_pos: any = [150 - 200 * 0.3 - 200 * 0, 400 - 125 * 0.3 + 125 * 0];
		var _group_a_vec_u: any = [200 * 0.8, 125 * 0.8];
		var _group_a_vec_v: any = [-200 * 0.6, 125 * 0.6];
		
		var _group_b_ori_pos: any = [350 - 200 * 0.3 + 200 * 0.2, 275 - 125 * 0.3 - 125 * 0.2];
		var _group_b_vec_u: any = [200 * 0.8, 125 * 0.8];
		var _group_b_vec_v: any = [-200 * 0.6, 125 * 0.6];
		
		BattleUtil._stand_pos_cache = {};
		BattleUtil._stand_pos_cache[BattleObjGroup.BOG_A] = {};
		BattleUtil._stand_pos_cache[BattleObjGroup.BOG_B] = {};

		for(var c = 0; c < col; ++c) {
			for(var r = 0; r < row; ++r) {
				var x = _group_a_ori_pos[0] + r / row * _group_a_vec_u[0] + c / col * _group_a_vec_v[0];
				var y = _group_a_ori_pos[1] + r / row * _group_a_vec_u[1] + c / col * _group_a_vec_v[1];
				BattleUtil._stand_pos_cache[BattleObjGroup.BOG_A][c * row + r] = [x, y];
			}
		}

		for(var c = 0; c < col; ++c) {
			for(var r = 0; r < row; ++r) {
				var x = _group_b_ori_pos[0] + r / row * _group_b_vec_u[0] + c / col * _group_b_vec_v[0];
				var y = _group_b_ori_pos[1] + r / row * _group_b_vec_u[1] + c / col * _group_b_vec_v[1];
				BattleUtil._stand_pos_cache[BattleObjGroup.BOG_B][c * row + r] = [x, y];
			}
		}
	}

	private static _standPosIdx(group: number, standPos: number): number {
		/**
		 *          [5 4 6]
		 *  GROUP_B [2 1 3]
		 * 
		 * 
		 *  GROUP_A [2 1 3]
		 *          [5 4 6]
		 */
		if(group == BattleObjGroup.BOG_A) {
			var idxs = [0, 1, 0, 2, 4, 3, 5];
			return idxs[standPos];
		}
		else {
			var idxs = [0, 4, 3, 5, 1, 0, 2];
			return idxs[standPos];
		}
	}
	public static getPos(group: number, standPos: number): [number, number] {
		if(!BattleUtil._stand_pos_cache) {
			BattleUtil.initPos();
		}

		var idx = BattleUtil._standPosIdx(group, standPos);
		return BattleUtil._stand_pos_cache[group][idx];
	}

	public static getCol(standPos: number): number {
		/**
		 *          [5 4 6]
		 *  GROUP_B [2 1 3]
		 * 
		 * 
		 *  GROUP_A [2 1 3]
		 *          [5 4 6]
		 */

		if(standPos == 2 || standPos == 5) {
			return 1;
		}
		else if(standPos == 1 || standPos == 4) {
			return 2;
		}
		else {
			return 3;
		}
	}

	public static getBeAtkedPriority(standPos: number): number {
		/**
		 *          [5 4 6]
		 *  GROUP_B [2 1 3]
		 * 
		 * 
		 *  GROUP_A [2 1 3]
		 *          [5 4 6]
		 */

		var priority = [0, 2, 1, 3, 5, 4, 6];
		return priority[standPos];
	}

	private static _move_dir_cache: any = null;
	public static getMoveDir(group: number): [number, number] {
		if(!BattleUtil._move_dir_cache) {
			var dir_x = 200;
			var dir_y = 125;
			var n = VectorUtil.calcNormalize(dir_x, dir_y);
			dir_x = n[0];
			dir_y = n[1];

			BattleUtil._move_dir_cache = {
				[BattleObjGroup.BOG_A]: [dir_x, -dir_y],
				[BattleObjGroup.BOG_B]: [-dir_x, dir_y],
			};
		}
		return BattleUtil._move_dir_cache[group];
	}
	
	public static getInitPos(group: number, standPos: number, engerStageDist: number): [number, number] {
		var pos = BattleUtil.getPos(group, standPos);
		var moveDir = BattleUtil.getMoveDir(group);
		return VectorUtil.calcTarPos(pos[0], pos[1], moveDir[0], moveDir[1], -engerStageDist);
	}

	public static calcTime(x1: number, y1: number, x2: number, y2: number, speed: number): number {
		var len = VectorUtil.calcLength(x2 - x1, y2 - y1);
		return len / speed;
	}

	public static calcSpeed(x1: number, y1: number, x2: number, y2: number, speed: number): [number, number] {
		var time = BattleUtil.calcTime(x1, y1, x2, y2, speed);
		return [(x2 - x1) / time, (y2 - y1) / time];
	}

	public static getStActByCol(stActs: any, srcGroup: number, srcCol: number, tarGroup: number, tarCol: number): number {
		var sa = stActs[srcGroup];
		if(srcCol == tarCol) {
			return sa[1];
		}
		else if(srcCol > tarCol) {
			return sa[0];
		}
		else {
			return sa[2];
		}
	}
}