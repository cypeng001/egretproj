class BattleLayer extends egret.DisplayObjectContainer {
	private static DEF_NUM_TIME = 1.5;
	
	private _battlePlayer: BattlePlayer;
	private _inBattle: boolean = false;

	private _bg: eui.Image = null;
	private _footprintLayer: egret.DisplayObjectContainer = null;
	private _entityLayer: egret.DisplayObjectContainer = null;
	private _smokeLayer: egret.DisplayObjectContainer = null;
	private _weaponLayer: egret.DisplayObjectContainer = null;
	private _effectLayer: egret.DisplayObjectContainer = null;
	private _numLayer: egret.DisplayObjectContainer = null;
	private _battleObjs: any = {};
	private _battleAIs: any = {};
	private _effectDatas: any = [];
	private _numDatas: any = [];
	private _smokeDatas: any = [];
	private _weaponDatas: any = [];
	private _footprintDatas: any = [];
	
	public constructor() {
		super();

		this.touchEnabled = false;
		this.touchChildren = false;

		this._battleObjs = {};
		this._battleAIs = {};
		this._effectDatas = [];

		this._bg = new eui.Image();
		this._bg.x = 0;
		this._bg.y = 0;
		this.addChild(this._bg);

		this._footprintLayer = new egret.DisplayObjectContainer();
		this.addChild(this._footprintLayer);

		this._entityLayer = new egret.DisplayObjectContainer();
		this.addChild(this._entityLayer);

		this._smokeLayer = new egret.DisplayObjectContainer();
		this.addChild(this._smokeLayer);

		this._weaponLayer = new egret.DisplayObjectContainer();
		this.addChild(this._weaponLayer);

		this._effectLayer = new egret.DisplayObjectContainer();
		this.addChild(this._effectLayer);

		this._numLayer = new egret.DisplayObjectContainer();
		this.addChild(this._numLayer);
	}

	public inBattle(): boolean {
		return this._inBattle;
	}
	
	public enterBattle(data: any) {
		this._battlePlayer = new BattlePlayer();
		this._battlePlayer.init(this, data);

		this._inBattle = true;
		this._bg.source = "resource/assets/image/battlebg/1.jpg";

		this.clearBattleObject();
		this.clearEffect();

		for(var k in data.myHeroList) {
			var heroData = data.myHeroList[k];
			var battleObj = this.createBattleObject(heroData);
			this.createBattleAI(battleObj);
		}

		for(var k in data.targetHeroList) {
			var heroData = data.targetHeroList[k];
			var battleObj = this.createBattleObject(heroData);
			this.createBattleAI(battleObj);
		}
	};

	public exitBattle() {
		this._battlePlayer.release();
		this._battlePlayer = null;

		this._inBattle = false;
		this._bg.source = "";

		this.clearBattleObject();
		this.clearEffect();
		this.clearBattleAI();
	}
	
	public update(interval: number): void {
		if(this._battlePlayer) {
			this._battlePlayer.update(interval);
		}
		
		for (var k in this._battleAIs) {
			var battleAI = this._battleAIs[k];
			battleAI.update(interval);
		}

		for (var k in this._battleObjs) {
			var battleObj = this._battleObjs[k];
			battleObj.update(interval);
		}

		this.updateEffect(interval);
		this.updateShowNum(interval);
		this.updateWeapon(interval);
		this.updateSmoke(interval);
		this.updateFootprint(interval);
	}

	public createBattleObject(data: any): BattleObject {
		var id = data.handle;
		var battleObj = new BattleObject();
		battleObj.init(this, data);
		this._entityLayer.addChild(battleObj);
		this._battleObjs[id] = battleObj;
		return battleObj;
	}

	public removeBattleObject(id: number): void {
		var battleObj = this._battleObjs[id];
		if(battleObj) {
			battleObj.release();
			if(battleObj.parent) {
				battleObj.parent.removeChild(battleObj);
			}
			delete this._battleObjs[id];
		}
	}

	public getBattleObject(id: number): BattleObject {
		return this._battleObjs[id];
	}

	public hasBattleObject(id: number): boolean {
		return this._battleObjs[id] != null ? true : false;
	}

	private clearBattleObject(): void {
		for (var k in this._battleObjs) {
			var battleObj = this._battleObjs[k];
			battleObj.release();
			if(battleObj.parent) {
				battleObj.parent.removeChild(battleObj);
			}
		}
		this._battleObjs = {};
	}

	public createBattleAI(battleObj: BattleObject): void {
		var battleAI = new BattleAI();
		battleAI.init(this, battleObj);
		battleAI.loadAI(1);
		this._battleAIs[battleObj.id] = battleAI;
	}

	public removeBattleAI(id: number): void {
		var battleAI = this._battleAIs[id];
		if(battleAI) {
			battleAI.release();
			delete this._battleAIs[id];
		}
	}

	public clearBattleAI(): void {
		for(var k in this._battleAIs) {
			var battleAI = this._battleAIs[k];
			battleAI.release();
		}
		this._battleAIs = {};
	}

	public createEffect(effId: number, x: number, y: number, z: number, life: number): void {
		var effect = new MovieClip();
		effect.x = x;
		effect.y = y;
		effect.loadUrl(ResDataPath.GetSkillEffPathByID(effId), true);
		this._effectLayer.addChild(effect);

		this._effectDatas.push({
			effId: effId,
			x: x,
			y: y,
			z: z,
			life: life,
			effect: effect
		});
	}

	public updateEffect(interval: number): void {
		for(var i in this._effectDatas) {
			var effectData = this._effectDatas[i];
			effectData.life -= interval;
			if(effectData.life < 0) {
				var effect = effectData.effect;
				if(effect && effect.parent) {
					effect.parent.removeChild(effect);
				}

				this._effectDatas.splice(i, 1);

				break;
			}
		}
	}

	public clearEffect(): void {
		for(var i in this._effectDatas) {
			var effectData = this._effectDatas[i];
			var effect = effectData.effect;
			if(effect && effect.parent) {
				effect.parent.removeChild(effect);
			}
		}
		this._effectDatas = [];
	}

	public createShowNum(x, y, status, value): void {
		var container = new egret.DisplayObjectContainer;

		y -= 50;

		container.x = x;
		container.y = y;

		if(status == BattleHitStatus.BHS_NORMAL) {
			var label = new eui.BitmapLabel;
			label.font = "font_pz_zi_j1_fnt";
			label.letterSpacing = -3;
			label.text = value;
			label.width = 100;
			label.anchorOffsetX = label.width / 2;
			container.addChild(label);
		}
		else if(status == BattleHitStatus.BHS_CRIT) {
			var image = new eui.Image;
			image.source = "ui_pz_bj";
			image.x = -100
			image.y = -30
			container.addChild(image);

			var label = new eui.BitmapLabel;
			label.font = "font_pz_zi_j1_fnt";
			label.letterSpacing = -3;
			label.text = value;
			label.width = 100;
			label.anchorOffsetX = label.width / 2;
			container.addChild(label);
		}
		else if(status == BattleHitStatus.BHS_MISS) {
			var image = new eui.Image;
			image.source = "ui_pz_sb";
			container.addChild(image);
		}
		
		this._numLayer.addChild(container);

		this._numDatas.push({
			time: BattleLayer.DEF_NUM_TIME,
			container: container
		});

		egret.Tween.get(container).to( {y: y - 20}, 500 );
	}

	protected updateShowNum(interval: number): void {
		for(var i = 0; i < this._numDatas.length; ++i) {
			var numData = this._numDatas[i];
			numData.time -= interval;
			if(numData.time < 0) {
				var container = numData.container;
				if(container && container.parent) {
					container.parent.removeChild(container);
				}
				this._numDatas.splice(i, 1);
				break;
			}
		}
	}

	public playBattleDefEff(battle_def: any): void {
		var def_id = battle_def.def_id;
		var hit_status = battle_def.hit_status;

		var defObj = this.getBattleObject(def_id);

		if(hit_status == BattleHitStatus.BHS_MISS) {
			this.createShowNum(defObj.x, defObj.y, hit_status, 0);
		}
		else {
			for(var j = 0; j < battle_def.def_attr_change.length; ++j) {
				var attr = battle_def.def_attr_change[j];
				if(attr.attr_id == BattleAttrID.BAID_HP) {
					this.createShowNum(defObj.x, defObj.y, hit_status, attr.delta_value);
				}
			}
		}

		defObj.refreshHpBar();

		var hp = defObj.hp;

		console.log("playBattleDefEff", hp);

		if(defObj.hp <= 0) {
			defObj.die();
		}
	}

	public playAttAttrChangeEff(att_id, att_attr_change: any): void {
		var attObj = this.getBattleObject(att_id);
		for(var i = 0; i < att_attr_change.length; ++i) {
			var attr = att_attr_change[i];
			if(attr.attr_id == BattleAttrID.BAID_HP) {
				this.createShowNum(attObj.x, attObj.y, BattleHitStatus.BHS_NORMAL, attr.delta_value);
			}
		}
	}

	public createBullet(srcId: number, tarId: number, bulletId: number, battleDef: any): void {
		var bulletCnf = BulletCnf[bulletId];

		var srcObj = this.getBattleObject(srcId);
		var tarObj = this.getBattleObject(tarId);

		var atkPos = srcObj.getAtkPos(tarId);
		var srcX = atkPos[0];
		var srcY = atkPos[1];

		var beatkedPos = tarObj.getBeAtkedPos();
		var tarX = beatkedPos[0];
		var tarY = beatkedPos[1];

		var life = VectorUtil.calcLength(tarX - srcX, tarY - srcY) / bulletCnf.speed;

		var group = srcObj.group;

		var bullet = new Bullet();
		bullet.init(this, {
			srcId: srcId,
			srcX: srcX,
			srcY: srcY,
			tarId: tarId,
			tarX: tarX,
			tarY: tarY,
			life: life,
			bulletId: bulletId,
			group: group,
			battleDef: battleDef,
		});
		this._weaponLayer.addChild(bullet);

		this._weaponDatas.push(bullet);

		bullet.execAtkAct();
	}

	public createMachineGun(srcId: number, tarId: number, machineGunId: number, battleDef: any): void {
		var machineGunCnf = MachineGunCnf[machineGunId];

		var srcObj = this.getBattleObject(srcId);
		var tarObj = this.getBattleObject(tarId);

		var atkPos = srcObj.getAtkPos(tarId);
		var srcX = atkPos[0];
		var srcY = atkPos[1];

		var beatkedPos = tarObj.getBeAtkedPos();
		var tarX = beatkedPos[0];
		var tarY = beatkedPos[1];

		var group = srcObj.group;

		var machineGun = new MachineGun();
		machineGun.init(this, {
			srcId: srcId,
			srcX: srcX,
			srcY: srcY,
			tarId: tarId,
			tarX: tarX,
			tarY: tarY,
			machineGunId: machineGunId,
			group: group,
			battleDef: battleDef,
		});
		this._weaponLayer.addChild(machineGun);

		this._weaponDatas.push(machineGun);

		machineGun.execAtkAct();
	}

	protected updateWeapon(interval: number): void {
		for(var i in this._weaponDatas) {
			var weapon = this._weaponDatas[i];
			weapon.update(interval);

			if(weapon.canExecBeAtkedAct()) {
				weapon.execBeAtkedAct();
			}
		}

		for(var i in this._weaponDatas) {
			var weapon = this._weaponDatas[i];
			if(weapon.life < 0) {
				if(weapon.parent) {
					weapon.parent.removeChild(weapon);
				}
				this._weaponDatas.splice(i, 1);

				break;
			}
		}
	}

	private static getSmokeImgPath(id: number): string {
		return "resource/assets/image/smoke/" + id + ".png";
	}

	public createSmoke(imgId: number, x: number, y: number): void {
		var SMOKE_DEF_LIFE = 1;

		var img = new eui.Image();
		img.x = x;
		img.y = y;
		img.source = BattleLayer.getSmokeImgPath(imgId);
		this.addChild(img);

		this._smokeDatas.push({
			img: img,
			life: SMOKE_DEF_LIFE,
		});

		egret.Tween.get(img).to({alpha: 0}, SMOKE_DEF_LIFE * 1000);
	}

	public updateSmoke(interval: number): void {
		for(var i in this._smokeDatas) {
			var smokeData = this._smokeDatas[i];
			smokeData.life -= interval;
			if(smokeData.life <= 0) {
				if(smokeData.img.parent) {
					smokeData.img.parent.removeChild(smokeData.img);
				}
				this._smokeDatas.splice(i, 1);
				break;
			}
		}
	}

	private static getFootprintImgPath(id: number): string {
		return "resource/assets/image/footprint/" + id + ".png";
	}

	public createFootprint(imgId: number, x: number, y: number, scale: number): void {
		var FOOTPRINT_DEF_LIFE = 1;

		var img = new eui.Image();
		img.x = x;
		img.y = y;
		img.source = BattleLayer.getFootprintImgPath(imgId);
		img.scaleX = img.scaleY = scale;
		this._footprintLayer.addChild(img);

		this._footprintDatas.push({
			img: img,
			life: FOOTPRINT_DEF_LIFE,
		});

		egret.Tween.get(img).to({alpha: 0}, FOOTPRINT_DEF_LIFE * 1000);
	}

	public updateFootprint(interval: number): void {
		for(var i in this._footprintDatas) {
			var footprintData = this._footprintDatas[i];
			footprintData.life -= interval;
			if(footprintData.life <= 0) {
				if(footprintData.img.parent) {
					footprintData.img.parent.removeChild(footprintData.img);
				}
				this._footprintDatas.splice(i, 1);
				break;
			}
		}
	}

	public shockScreen(dirX: number = 0, dirY: number = 0): void {
		var dist = 1;
		var tick = 50;
		if(dirX == 0 && dirY == 0) {
			dirX = MathUtil.randInRange(-10, 10);
			dirY = MathUtil.randInRange(-10, 10);
			var dir = VectorUtil.calcNormalize(dirX, dirY);
			dirX = dir[0];
			dirY = dir[1];
		}
		egret.Tween.get(this).to({x: - dirX * dist, y: - dirY * dist}, tick)
			.to({x: 0, y: 0}, 
			tick);
	}
}