var BattleResult = {
    type: 0,					//0 : integer   		# 类型    1普通剧情 2xx副本
    targetId: 0,				//1 : integer	  		# 目标id  MonId | FubenId
    winFlag: 0,			        //	2 : integer   		# 胜利方标识  1=我方  2=对方
    groupFlag: 0,				//3 : integer   		# 组队标识    1=普通  2=组队
    myHeroList: [],				//4 : *battle_hero  	# 我方英雄信息
	targetHeroList: [],			//5 : *battle_hero 	# 对方英雄信息
	battleReport: [], 			//6 : *battle_report 	# 战斗过程播报
	reward: [] 					//7 : *reward_data
};


BattleResult.myHeroList.push({
    handle: 1,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 4,   	//2 : integer   # 等级
    posFlag: 1,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 1,    //4 : integer   # 角色处在第几个位置
    hpLim: 1000,	//5 : integer   # 气血上限
    hp: 1000,       //6 : integer   # 当前剩余气血
    heroid: 10001,  //7 : integer   # 英雄ID
    name: "坦克1",       //8 : string   # 角色名字
});

BattleResult.myHeroList.push({
    handle: 2,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 3,   	//2 : integer   # 等级
    posFlag: 1,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 2,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,        //6 : integer   # 当前剩余气血
    heroid: 10002,  //7 : integer   # 英雄ID
    name: "坦克2",       //8 : string   # 角色名字
});

BattleResult.myHeroList.push({
    handle: 3,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 3,   	//2 : integer   # 等级
    posFlag: 1,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 3,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,        //6 : integer   # 当前剩余气血
    heroid: 10002,  //7 : integer   # 英雄ID
    name: "坦克3",       //8 : string   # 角色名字
});

BattleResult.myHeroList.push({
    handle: 4,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 3,   	//2 : integer   # 等级
    posFlag: 1,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 4,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,        //6 : integer   # 当前剩余气血
    heroid: 10002,  //7 : integer   # 英雄ID
    name: "坦克4",       //8 : string   # 角色名字
});

BattleResult.myHeroList.push({
    handle: 5,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 3,   	//2 : integer   # 等级
    posFlag: 1,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 5,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,        //6 : integer   # 当前剩余气血
    heroid: 10002,  //7 : integer   # 英雄ID
    name: "坦克5",       //8 : string   # 角色名字
});

BattleResult.myHeroList.push({
    handle: 6,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 3,   	//2 : integer   # 等级
    posFlag: 1,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 6,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,        //6 : integer   # 当前剩余气血
    heroid: 10002,  //7 : integer   # 英雄ID
    name: "坦克6",       //8 : string   # 角色名字
});

/*
BattleResult.myHeroList.push({
    handle: 7,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 3,   	//2 : integer   # 等级
    posFlag: 1,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 7,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,        //6 : integer   # 当前剩余气血
    heroid: 10002,  //7 : integer   # 英雄ID
    name: "灰熊坦克7",       //8 : string   # 角色名字
});

BattleResult.myHeroList.push({
    handle: 8,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 3,   	//2 : integer   # 等级
    posFlag: 1,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 8,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,        //6 : integer   # 当前剩余气血
    heroid: 10002,  //7 : integer   # 英雄ID
    name: "灰熊坦克8",       //8 : string   # 角色名字
});
*/

BattleResult.targetHeroList.push({
    handle: 11,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 10,   	//2 : integer   # 等级
    posFlag: 2,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 1,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,       //6 : integer   # 当前剩余气血
    heroid: 10001,  //7 : integer   # 英雄ID
    name: "坦克1",       //8 : string   # 角色名字
});

BattleResult.targetHeroList.push({
    handle: 12,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 10,   	//2 : integer   # 等级
    posFlag: 2,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 2,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,       //6 : integer   # 当前剩余气血
    heroid: 10001,  //7 : integer   # 英雄ID
    name: "坦克2",       //8 : string   # 角色名字
});

BattleResult.targetHeroList.push({
    handle: 13,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 10,   	//2 : integer   # 等级
    posFlag: 2,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 3,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,       //6 : integer   # 当前剩余气血
    heroid: 10001,  //7 : integer   # 英雄ID
    name: "坦克3",       //8 : string   # 角色名字
});

BattleResult.targetHeroList.push({
    handle: 14,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 10,   	//2 : integer   # 等级
    posFlag: 2,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 4,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,       //6 : integer   # 当前剩余气血
    heroid: 10002,  //7 : integer   # 英雄ID
    name: "坦克4",       //8 : string   # 角色名字
});

BattleResult.targetHeroList.push({
    handle: 15,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 10,   	//2 : integer   # 等级
    posFlag: 2,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 5,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,       //6 : integer   # 当前剩余气血
    heroid: 10002,  //7 : integer   # 英雄ID
    name: "坦克5",       //8 : string   # 角色名字
});

BattleResult.targetHeroList.push({
    handle: 16,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 10,   	//2 : integer   # 等级
    posFlag: 2,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 6,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,       //6 : integer   # 当前剩余气血
    heroid: 10001,  //7 : integer   # 英雄ID
    name: "天启坦克6",       //8 : string   # 角色名字
});

/*
BattleResult.targetHeroList.push({
    handle: 17,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 10,   	//2 : integer   # 等级
    posFlag: 2,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 7,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,       //6 : integer   # 当前剩余气血
    heroid: 10001,  //7 : integer   # 英雄ID
    name: "天启坦克7",       //8 : string   # 角色名字
});

BattleResult.targetHeroList.push({
    handle: 18,		//0 : integer   # id
    type: 1,  	  	//1 : integer   # 类型  1主角 2宠物 3怪物
    level: 10,   	//2 : integer   # 等级
    posFlag: 2,   	//3 : integer   # 敌我标识  1我方 2敌方
    position: 8,    //4 : integer   # 角色处在第几个位置
    hpLim: 1500,	//5 : integer   # 气血上限
    hp: 1500,       //6 : integer   # 当前剩余气血
    heroid: 10001,  //7 : integer   # 英雄ID
    name: "天启坦克8",       //8 : string   # 角色名字
});
*/
var battle_report_1 = {
    round: 1,			//0 : integer			# 当前回合数
	one_round_data: []	//1 : *battle_round_data 	# 一次进攻的播报数据
}

var battle_round_data_1_1 = {
	att_id: 1,				//0 : integer 		 # 攻击方的id
	skill_id: 1002,			//1 : integer			 # 技能id
	skill_level: 1,		//2 : integer 		 # 技能等级
	att_attr_change: [],		//3 : *battle_attr     # 攻击方属性变更列表
	att_del_buff:[],		//4 : *battle_buff 	 # 攻击方删除buff
	att_add_buff:[],		//5 : *battle_buff 	 # 攻击方增加buff
	def_list: [
        {
            def_id: 11, 				//0 : integer 		# 防御方id
            hit_status: 1,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -666}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
        {
            def_id: 12, 				//0 : integer 		# 防御方id
            hit_status: 2,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1100, delta_value: -1333}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
        {
            def_id: 13, 				//0 : integer 		# 防御方id
            hit_status: 1,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1000, delta_value: -666}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
    ]			//6 : *battle_def		 # 防守方列表数据
}

var battle_round_data_1_2 = {
	att_id: 13,				//0 : integer 		 # 攻击方的id
	skill_id: 1002,			//1 : integer			 # 技能id
	skill_level: 13,		//2 : integer 		 # 技能等级
	att_attr_change: [],		//3 : *battle_attr     # 攻击方属性变更列表
	att_del_buff:[],		//4 : *battle_buff 	 # 攻击方删除buff
	att_add_buff:[],		//5 : *battle_buff 	 # 攻击方增加buff
	def_list: [
        {
            def_id: 1, 				//0 : integer 		# 防御方id
            hit_status: 1,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -333}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
        {
            def_id: 2, 				//0 : integer 		# 防御方id
            hit_status: 3,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
    ]			//6 : *battle_def		 # 防守方列表数据
}

var battle_round_data_1_3 = {
	att_id: 2,				//0 : integer 		 # 攻击方的id
	skill_id: 1003,			//1 : integer			 # 技能id
	skill_level: 13,		//2 : integer 		 # 技能等级
	att_attr_change: [],		//3 : *battle_attr     # 攻击方属性变更列表
	att_del_buff:[],		//4 : *battle_buff 	 # 攻击方删除buff
	att_add_buff:[],		//5 : *battle_buff 	 # 攻击方增加buff
	def_list: [
        {
            def_id: 12, 				//0 : integer 		# 防御方id
            hit_status: 2,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -666}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
    ]			//6 : *battle_def		 # 防守方列表数据
}

var battle_round_data_1_4 = {
	att_id: 5,				//0 : integer 		 # 攻击方的id
	skill_id: 1001,			//1 : integer			 # 技能id
	skill_level: 13,		//2 : integer 		 # 技能等级
	att_attr_change: [],		//3 : *battle_attr     # 攻击方属性变更列表
	att_del_buff:[],		//4 : *battle_buff 	 # 攻击方删除buff
	att_add_buff:[],		//5 : *battle_buff 	 # 攻击方增加buff
	def_list: [
        {
            def_id: 11, 				//0 : integer 		# 防御方id
            hit_status: 2,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -555}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
        {
            def_id: 13, 				//0 : integer 		# 防御方id
            hit_status: 2,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -333}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
    ]			//6 : *battle_def		 # 防守方列表数据
}

var battle_round_data_1_5 = {
	att_id: 15,				//0 : integer 		 # 攻击方的id
	skill_id: 1001,			//1 : integer			 # 技能id
	skill_level: 13,		//2 : integer 		 # 技能等级
	att_attr_change: [],		//3 : *battle_attr     # 攻击方属性变更列表
	att_del_buff:[],		//4 : *battle_buff 	 # 攻击方删除buff
	att_add_buff:[],		//5 : *battle_buff 	 # 攻击方增加buff
	def_list: [
        {
            def_id: 1, 				//0 : integer 		# 防御方id
            hit_status: 2,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -555}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
        {
            def_id: 2, 				//0 : integer 		# 防御方id
            hit_status: 1,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -333}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
        {
            def_id: 3, 				//0 : integer 		# 防御方id
            hit_status: 2,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -333}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
    ]			//6 : *battle_def		 # 防守方列表数据
}

var battle_round_data_1_6 = {
	att_id: 4,				//0 : integer 		 # 攻击方的id
	skill_id: 1002,			//1 : integer			 # 技能id
	skill_level: 13,		//2 : integer 		 # 技能等级
	att_attr_change: [],		//3 : *battle_attr     # 攻击方属性变更列表
	att_del_buff:[],		//4 : *battle_buff 	 # 攻击方删除buff
	att_add_buff:[],		//5 : *battle_buff 	 # 攻击方增加buff
	def_list: [
        {
            def_id: 11, 				//0 : integer 		# 防御方id
            hit_status: 2,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -1555}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
        {
            def_id: 13, 				//0 : integer 		# 防御方id
            hit_status: 1,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -1333}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
        {
            def_id: 14, 				//0 : integer 		# 防御方id
            hit_status: 2,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -733}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
    ]			//6 : *battle_def		 # 防守方列表数据
}

var battle_round_data_1_7 = {
	att_id: 14,				//0 : integer 		 # 攻击方的id
	skill_id: 1003,			//1 : integer			 # 技能id
	skill_level: 13,		//2 : integer 		 # 技能等级
	att_attr_change: [],		//3 : *battle_attr     # 攻击方属性变更列表
	att_del_buff:[],		//4 : *battle_buff 	 # 攻击方删除buff
	att_add_buff:[],		//5 : *battle_buff 	 # 攻击方增加buff
	def_list: [
        {
            def_id: 2, 				//0 : integer 		# 防御方id
            hit_status: 2,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -2555}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
    ]			//6 : *battle_def		 # 防守方列表数据
}

var battle_round_data_1_8 = {
	att_id: 5,				//0 : integer 		 # 攻击方的id
	skill_id: 1002,			//1 : integer			 # 技能id
	skill_level: 13,		//2 : integer 		 # 技能等级
	att_attr_change: [],		//3 : *battle_attr     # 攻击方属性变更列表
	att_del_buff:[],		//4 : *battle_buff 	 # 攻击方删除buff
	att_add_buff:[],		//5 : *battle_buff 	 # 攻击方增加buff
	def_list: [
        {
            def_id: 14, 				//0 : integer 		# 防御方id
            hit_status: 1,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -900}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
        {
            def_id: 15, 				//0 : integer 		# 防御方id
            hit_status: 1,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -300}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
        {
            def_id: 16, 				//0 : integer 		# 防御方id
            hit_status: 1,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -400}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
    ]			//6 : *battle_def		 # 防守方列表数据
}

var battle_round_data_1_9 = {
	att_id: 6,				//0 : integer 		 # 攻击方的id
	skill_id: 1001,			//1 : integer			 # 技能id
	skill_level: 13,		//2 : integer 		 # 技能等级
	att_attr_change: [],		//3 : *battle_attr     # 攻击方属性变更列表
	att_del_buff:[],		//4 : *battle_buff 	 # 攻击方删除buff
	att_add_buff:[],		//5 : *battle_buff 	 # 攻击方增加buff
	def_list: [
        {
            def_id: 15, 				//0 : integer 		# 防御方id
            hit_status: 1,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -1800}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
        {
            def_id: 16, 				//0 : integer 		# 防御方id
            hit_status: 1,			//1 : integer	 		# 防御方受伤类型： 1正常伤害 2暴击 3闪避
            def_attr_change: [{attr_id: 1, attr_value: 1500, delta_value: -1400}], 	//2 : *battle_attr	# 防御方属性变更
            def_del_buff: [],		//3 : *battle_buff 	# 防御方删除buff
            def_add_buff: []		//4 : *battle_buff	# 防御方增加buff
        },
    ]			//6 : *battle_def		 # 防守方列表数据
}

battle_report_1.one_round_data.push(battle_round_data_1_1);
battle_report_1.one_round_data.push(battle_round_data_1_2);
battle_report_1.one_round_data.push(battle_round_data_1_3);
battle_report_1.one_round_data.push(battle_round_data_1_4);
battle_report_1.one_round_data.push(battle_round_data_1_5);
battle_report_1.one_round_data.push(battle_round_data_1_6);
battle_report_1.one_round_data.push(battle_round_data_1_7);
battle_report_1.one_round_data.push(battle_round_data_1_8);
battle_report_1.one_round_data.push(battle_round_data_1_9);

BattleResult.battleReport.push(battle_report_1);

var BattleObjCnf = {
    10001: {
        resType: 1,
        resId: 10001,
        name: "天启坦克",
        scale: 0.65,
        atkOffsetA: [66, -45, 8, -55, 90, -15],
        atkOffsetB: [-66, 45, -70, -10, 10, 30],
        beatkedOffsetY: -10,
        dieEffId: 10010,
        dieSoundId: 2001,
        enterSoundId: 2011,
        footprintA: [10001, 0.1, -13, -13, 1],
        footprintB: [10001, 0.1, -10, -10, 1],
    },
    10002: {
        resType: 1,
        resId: 10002,
        name: "灰熊坦克",
        scale: 0.75,
        atkOffsetA: [66, -45, 8, -55, 90, -15],
        atkOffsetB: [-66, 45, -70, -10, 10, 30],
        beatkedOffsetY: -10,
        dieEffId: 10010,
        dieSoundId: 2001,
        enterSoundId: 2011,
        footprintA: [10001, 0.1, -13, -13, 1],
        footprintB: [10001, 0.1, -10, -10, 1],
    }
}

var SkillCnf = {
    1001: {
        name: "炮弹",
        skill_act_id: [10011]
    },
    1002: {
        name: "导弹",
        skill_act_id: [10012]
    },
    1003: {
        name: "机枪",
        skill_act_id: [10013]
    },
}
var SkillActCnf = {
    10011: {
        name: "导弹",
        weapon_type: 1,
        weapon_id: 1,
        particle: [
            //[1, 1, 10001, 0, 0, 0, 0, 9999]
        ],
        sound: [],
        atk_mode: 1,
        recoil: false,
        multiInterval: 0.2,
        atkEffA: 0,
		atkEffB: 0,
        atkSound: 0,
    },
    10012: {
        name: "炮弹",
        weapon_type: 1,
        weapon_id: 2,
        particle: [
            //[1, 1, 10001, 0, 0, 0, 0, 9999]
        ],
        sound: [],
        atk_mode: 2,
        recoil: true,
        multiInterval: 0.6,
        atkEffA: 0,
		atkEffB: 0,
        atkSound: 0,
    },
    10013: {
        name: "机枪",
        weapon_type: 2,
        weapon_id: 1,
        particle: [
            //[1, 1, 10001, 0, 0, 0, 0, 9999]
        ],
        sound: [],
        atk_mode: 0,
        recoil: false,
        multiInterval: 0,
        atkEffA: 0,
		atkEffB: 0,
        atkSound: 0,
    },
}