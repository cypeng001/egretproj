enum WeaponType {
	WT_BULLET			= 1,
	WT_MACHINEGUN		= 2,
}

enum BulletTrack {
	BT_LINEAR			= 1,
	BT_BEZIERAT2		= 2,
};