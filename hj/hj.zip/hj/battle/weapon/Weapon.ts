class Weapon extends egret.DisplayObjectContainer {
	protected _battleLayer: BattleLayer = null;
	protected _data: any = null;
	protected _dir: [number, number] = [0, 0];
	protected _life: number = 0;
	protected _maxLife: number = 0;
	protected _execBeAtkedAct: boolean = false;

	public constructor() {
		super();
	}

	public getType(): number {
		return -1;
	}

	public set life(val: number) {
		this._life = val;
	}

	public get life(): number {
		return this._life;
	}

	public set maxLife(val: number) {
		this._maxLife = val;
	}

	public get maxLife(): number {
		return this._maxLife;
	}

	public get battleDef(): any {
		return this._data.battleDef;
	}

	public get srcId(): number {
		return this._data.srcId;
	}

	public getSrcObj(): BattleObject {
		return this._battleLayer.getBattleObject(this.srcId);
	}

	public get srcX(): number {
		return this._data.srcX;
	}

	public get srcY(): number {
		return this._data.srcY;
	}

	public get tarId(): number {
		return this._data.tarId;
	}

	public getTarObj(): BattleObject {
		return this._battleLayer.getBattleObject(this.tarId);
	}

	public get tarX(): number {
		return this._data.tarX;
	}

	public get tarY(): number {
		return this._data.tarY;
	}

	public init(battleLayer: BattleLayer, data: any): void {
		this._battleLayer = battleLayer;
		this._data = data;

		this.x = data.srcX;
		this.y = data.srcY;
	}

	public update(interval: number): void {
		this.life -= interval;
	}

	public execAtkAct(): void {

	}

	public canExecBeAtkedAct(): boolean {
		return false;
	}

	public execBeAtkedAct(): void {
		this._execBeAtkedAct = true;
	}
}