class MachineGun extends Weapon {
	private static DEF_MAX_LIFE: number = 1.5;

	private _dmgTick: number = 0;

	private _machineGunId: number = 0;
	private _machineGunCnf: any = null;

	private _mc: MovieClip = null;

	public constructor() {
		super();
	}

	public getType(): number {
		return WeaponType.WT_MACHINEGUN;
	}

	private get effId(): number {
		return this._machineGunCnf.effId;
	}

	private get effLen(): number {
		return this._machineGunCnf.effLen;
	}

	private get atkEffId(): number {
		if(this._data.group == BattleObjGroup.BOG_A) {
			return this._machineGunCnf.atkEffA;
		}
		else {
			return this._machineGunCnf.atkEffB;
		}
	}

	private get beatkedEffId(): number {
		return this._machineGunCnf.beatkedEff;
	}

	private get atkSound(): number {
		return this._machineGunCnf.atkSound;
	}

	private get beatkedSound(): number {
		return this._machineGunCnf.beatkedSound;
	}

	public init(battleLayer: BattleLayer, data: any): void {
		super.init(battleLayer, data);

		this._machineGunId = data.machineGunId;
		this._machineGunCnf = MachineGunCnf[data.machineGunId];

		this.maxLife = this.life = this._machineGunCnf.life;
		this._dmgTick = this._machineGunCnf.dmgTick;

		this._mc = new MovieClip();
		this._mc.loadUrl(ResDataPath.GetSkillEffPathByID(this.effId), true);
		this.addChild(this._mc);

		this.rotation = VectorUtil.calcDegree(this.tarX - this.srcX, this.tarY - this.srcY);
		this.scaleX = this.scaleY = VectorUtil.calcLength(this.tarX - this.srcX, 
			this.tarY - this.srcY) 
			/ this.effLen;
	}

	public update(interval: number): void {
		super.update(interval);

		this._dmgTick -= interval;
	}

	public execAtkAct(): void {
		super.execAtkAct();

		var srcObj = this.getSrcObj();

		if(this.atkEffId > 0) {
			this._battleLayer.createEffect(this.atkEffId, this.srcX, this.srcY, 0, 1);
		}

		if(this.atkSound && this.atkSound > 0) {
			SoundMgr.getInstance().playSound(this.atkSound);
		}
	}

	public canExecBeAtkedAct(): boolean {
		if(this._execBeAtkedAct) {
			return false;
		}

		return this._dmgTick <= 0;
	}

	public execBeAtkedAct(): void {
		super.execBeAtkedAct();

		var battleDef = this.battleDef;

		if(this.beatkedEffId > 0) {
			this._battleLayer.createEffect(this.beatkedEffId, this.tarX, this.tarY, 0, 1);
		}

		if(this.beatkedSound && this.beatkedSound > 0) {
			SoundMgr.getInstance().playSound(this.beatkedSound);
		}

		this._battleLayer.playBattleDefEff(battleDef);
	}
}