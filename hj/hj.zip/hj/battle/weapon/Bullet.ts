class Bullet extends Weapon {
	private static DEF_SMOKE_TICK: number = 0.1;

	private _img: eui.Image = null;

	private _bulletId: number = 0;
	private _bulletCnf: any = null;
	private _ctrlPt: [number, number] = [0, 0];
	private _smokeTick: number = 0;

	public constructor() {
		super();
	}

	public getType(): number {
		return WeaponType.WT_BULLET;
	}

	private static getBulletImgPath(id: number): string {
		return "resource/assets/image/bullet/" + id + ".png";
	}

	private get trackType(): number {
		return this._bulletCnf.trackType;
	}

	private get speed(): number {
		return this._bulletCnf.speed;
	}

	private get atkEffId(): number {
		if(this._data.group == BattleObjGroup.BOG_A) {
			return this._bulletCnf.atkEffA;
		}
		else {
			return this._bulletCnf.atkEffB;
		}
	}

	private get beatkedEffId(): number {
		return this._bulletCnf.beatkedEff;
	}

	private get atkShock(): boolean {
		return this._bulletCnf.atkShock;
	}

	private get beatkedShock(): boolean {
		return this._bulletCnf.beatkedShock;
	}

	private get atkSound(): number {
		return this._bulletCnf.atkSound;
	}

	private get beatkedSound(): number {
		return this._bulletCnf.beatkedSound;
	}

	private get smokeImg(): number {
		return this._bulletCnf.smokeImg;
	}

	public init(battleLayer: BattleLayer, data: any): void {
		super.init(battleLayer, data);

		this._bulletId = data.bulletId;
		this._bulletCnf = BulletCnf[this._bulletId];


		if(this.trackType == BulletTrack.BT_LINEAR) {
			this.maxLife = this.life = (VectorUtil.calcLength(this._data.tarX - this._data.srcX, 
				this._data.tarY - this._data.srcY)) / this.speed;

			this._dir = VectorUtil.calcDir(this._data.srcX, this._data.srcY,
				this._data.tarX, this._data.tarY);

			this.adjustRotate();
		} else if(this.trackType == BulletTrack.BT_BEZIERAT2) {
			this.maxLife = this.life = 1;

			var tarObj = this.getTarObj();
			var tarCol = tarObj.getCol();

			if(this._data.group == BattleObjGroup.BOG_A) {
				this._ctrlPt[0] = (data.srcX + data.tarX) * (tarCol - 1) * 0.1;
				this._ctrlPt[1] = (data.srcY + data.tarY) * 0.5 - (100 - (tarCol - 1) * 20);
			}
			else {
				this._ctrlPt[0] = data.srcX - (20 + (tarCol - 1) * 20);
				this._ctrlPt[1] = data.srcY - (100 - (tarCol - 1) * 20);
			}
		}

		this._img = new eui.Image();
		this._img.source = Bullet.getBulletImgPath(this._bulletCnf.imgId);
		this.addChild(this._img);

		this.scaleX = this.scaleY = this._bulletCnf.scale;
	}

	public update(interval: number): void {
		super.update(interval);

		if(this.trackType == BulletTrack.BT_LINEAR) {
			this.x += this._dir[0] * this.speed * interval;
			this.y += this._dir[1] * this.speed * interval;
		}
		else if(this.trackType == BulletTrack.BT_BEZIERAT2) {
			var t = (this.maxLife - this.life) / this.maxLife;

			var pos = MathUtil.bezierat2(this._data.srcX, this._data.srcY,
				this._ctrlPt[0], this._ctrlPt[1],
				this._data.tarX, this._data.tarY,
				t
				);

			var oldX = this.x;
			var oldY = this.y;

			this.x = pos[0];
			this.y = pos[1];

			this._dir = VectorUtil.calcDir(oldX, oldY, this.x, this.y);

			this.adjustRotate();
		}

		if(this.life < 0) {
			this.x = this._data.tarX;
			this.y = this._data.tarY;
		}

		this.updateSmoke(interval);
	}

	private updateSmoke(interval: number): void {
		if(this.smokeImg > 0) {
			this._smokeTick -= interval;
			if(this._smokeTick < 0) {
				this._smokeTick = Bullet.DEF_SMOKE_TICK;

				this._battleLayer.createSmoke(this.smokeImg, this.x, this.y);
			}
		}
	}
	
	private adjustRotate(): void {
		this.rotation = VectorUtil.calcDegree(this._dir[0], this._dir[1]);
	}

	public execAtkAct(): void {
		super.execAtkAct();

		var srcObj = this.getSrcObj();

		if(this.atkEffId > 0) {
			this._battleLayer.createEffect(this.atkEffId, this.srcX, this.srcY, 0, 1);
		}

		if(this.atkShock) {
			var dir = srcObj.getMoveDir();
			this._battleLayer.shockScreen(-dir[0], -dir[1]);
		}

		if(this.atkSound && this.atkSound > 0) {
			SoundMgr.getInstance().playSound(this.atkSound);
		}
	}

	public canExecBeAtkedAct(): boolean {
		if(this._execBeAtkedAct) {
			return false;
		}

		return this.life <= 0;
	}

	public execBeAtkedAct(): void {
		super.execBeAtkedAct();

		var battleDef = this.battleDef;

		if(this.beatkedEffId > 0) {
			this._battleLayer.createEffect(this.beatkedEffId, this.tarX, this.tarY, 0, 1);
		}

		if(this.beatkedShock) {
			this._battleLayer.shockScreen();
		}

		if(this.beatkedSound && this.beatkedSound > 0) {
			SoundMgr.getInstance().playSound(this.beatkedSound);
		}

		if(this.trackType == BulletTrack.BT_LINEAR) {
			var tarObj = this.getTarObj();
			if(tarObj.hp > 0 
				&& tarObj.resType == BattleObjResType.BORT_TANK) {
				tarObj.playBeAtkedAct();
			}
		}
		
		this._battleLayer.playBattleDefEff(battleDef);
	}
}