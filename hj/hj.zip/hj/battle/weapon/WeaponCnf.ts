var BulletCnf = {
	1: {
		name: "导弹",
		imgId: 10001,
		trackType: 2,
		speed: 200,
		scale: 0.3,
		atkEffA: 0,
		atkEffB: 0,
		beatkedEff: 10003,
		atkShock: false,
        beatkedShock: true,
		atkSound: 2002,
		beatkedSound: 2003,
		smokeImg: 1001,
	},
	2: {
		name: "炮弹",
		imgId: 10002,
		trackType: 1,
		speed: 1500,
		scale: 0.5,
		atkEffA: 10004,
		atkEffB: 10005,
		beatkedEff: 10006,
		atkShock: false,
        beatkedShock: true,
		atkSound: 2010,
		beatkedSound: 0,
		smokeImg: 0,
	},
};

var MachineGunCnf = {
	1: {
		name: "机枪1",
		effId: 10007,
		effLen: 150,
		atkEffA: 10008,
		atkEffB: 10008,
		beatkedEff: 10009,
		atkSound: 2007,
		beatkedSound: 0,
		dmgTick: 0.3,
		life: 1,
	}
}